package com.example.amd.helloworld;

import android.content.res.AssetFileDescriptor;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.os.Debug;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.File;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    String                  userText;
    AudioTrack              track;
    HashMap<String, String> freqMap;
    MediaPlayer             mp;

    private void playSound(double frequency, int duration) {

        int mBufferSize = AudioTrack.getMinBufferSize(44100,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_8BIT);

        AudioTrack mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, 44100,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                mBufferSize, AudioTrack.MODE_STREAM);

        double[] mSound = new double[4410];
        short[] mBuffer = new short[duration];
        for (int i = 0; i < mSound.length; i++) {
            mSound[i] = Math.sin((2.0*Math.PI * i/(44100/frequency)));
            mBuffer[i] = (short) (mSound[i]*Short.MAX_VALUE);
        }

        mAudioTrack.setStereoVolume(AudioTrack.getMaxVolume(), AudioTrack.getMaxVolume());
        mAudioTrack.play();

        mAudioTrack.write(mBuffer, 0, mSound.length);
        mAudioTrack.stop();
        mAudioTrack.release();

    }

    private AudioTrack generateTone(double freqHz, int durationMs) {
        int count = (int)(44100.0 * 2.0 * (durationMs / 1000.0)) & ~1;
        short[] samples = new short[count];
        for(int i = 0; i < count; i += 2){
            short sample = (short)(Math.sin(2 * Math.PI * i / (44100.0 / freqHz)) * 0x7FFF);
            samples[i + 0] = sample;
            samples[i + 1] = sample;
        }
        AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC,
                                44100,
                                AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT,
                                count * (Short.SIZE / 8), AudioTrack.MODE_STATIC);
        track.write(samples, 0, count);
        return track;
    }

    public void playAudio(String fileName){
        try {

            mp.reset();

            int id = this.getResources().getIdentifier(fileName, "raw", this.getPackageName());

            AssetFileDescriptor afd = this.getResources().openRawResourceFd(id);
            if (afd == null) return;
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();

            //mp.setDataSource(path + File.separator + fileName);
            mp.prepare();
            mp.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        freqMap = new HashMap<String, String>();
        freqMap.put("a", "wa200");
        freqMap.put("b", "wb240");
        freqMap.put("c", "wc280");
        freqMap.put("d", "wd320");
        freqMap.put("e", "we360");
        freqMap.put("f", "wf400");
        freqMap.put("g", "wg440");
        freqMap.put("h", "wh480");
        freqMap.put("i", "wi520");
        freqMap.put("j", "wj560");
        freqMap.put("k", "wk600");
        freqMap.put("l", "wl640");
        freqMap.put("m", "wm680");
        freqMap.put("n", "wn720");
        freqMap.put("o", "wo760");
        freqMap.put("p", "wp800");
        freqMap.put("q", "wq840");
        freqMap.put("r", "wr880");
        freqMap.put("s", "ws920");
        freqMap.put("t", "wt960");
        freqMap.put("u", "wu1000");
        freqMap.put("v", "wv1040");
        freqMap.put("w", "ww1080");
        freqMap.put("x", "wx1120");
        freqMap.put("y", "wy1160");
        freqMap.put("z", "wz1200");
        freqMap.put(" ", "wspace1800");

        mp = new MediaPlayer();
        Button btn = (Button) findViewById(R.id.button1);
        final EditText edtText = (EditText) findViewById(R.id.editText1);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                userText = edtText.getText().toString();
                for (final char c: userText.toCharArray()) {
                    Log.d("AMD", freqMap.get(String.valueOf(c)));

                    /*
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    */

                    playAudio(freqMap.get(String.valueOf(c)));

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    //playSound(Double.parseDouble(freqMap.get(String.valueOf(c))), 44100);
                    //track = generateTone(Double.parseDouble(freqMap.get(String.valueOf(c))), 1000);
                    //track.play();

                    /*
                    new Timer().schedule(new TimerTask() {
                        @Override
                        public void run() {
                            track = generateTone(Double.parseDouble(freqMap.get(String.valueOf(c))), 1000);
                            track.play();
                        }
                    }, 1000);
                    */

                    /*
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            track = generateTone(Double.parseDouble(freqMap.get(String.valueOf(c))), 1000);
                            track.play();
                        }
                    }, 1000);
                    */
                }
            }
        });
    }
}
